import { useState, useEffect } from "react"
import alanBtn from '@alan-ai/alan-sdk-web';

function App() {

  const [cart, setCart] = useState([])
  const [menuItems, setMenuItems] = useState([])

  useEffect(() => {
    alanBtn({
      key: 'f6ac4a0ab4e8c0ba0994096a83a933fc2e956eca572e1d8b807a3e2338fdd0dc/stage',
      onCommand: (commandData) => {
        if (commandData.command === 'getMenu') {
          setMenuItems(commandData.data)
        }
        else if (commandData.command === 'addToCart') {
          addToCart(commandData.data)
        }
      }
    });
  }, []);

  // const spaces="    ";
  const addToCart = (menuItem) => {
    setCart((oldCart) => {
      return [...oldCart, menuItem]
    })

  }

  return (
    <div className="App">
       <ul className="list-group">
        {menuItems.map((menuItem) => (
          <li key={menuItem.name} className="list-group-item">
            <div className="row">
              <div className="col-md-4">
                {menuItem.name}
              </div>
              <div className="col-md-4">
                ${menuItem.price}
              </div>
              <div className="col-md-4">
                {menuItem.category}
              </div>
            </div>
          </li>
        ))}
      </ul>

      <h2>Cart</h2>


      {/* <p style={{color: "red"}}>Try Saying "Show Me The Menu"</p> */}

      <ul className="list-group">
        {cart.map((cartItem) => (
          <li key={cartItem.name} className="list-group-item bg-info text-white">
            <div className="row">
              <div className="col-md-4">
                {cartItem.name}
              </div>
              <div className="col-md-4">
                ${cartItem.price}
              </div>
              <div className="col-md-4">
                {cartItem.category}
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
