import React from "react";

function Contact() {
    return (

        <div>
           <p1>Hemant Kumar Meena</p1>
           <p1>Tarun Mourya</p1>
           <p1>Pankaj Gwal</p1>
        </div>
    )
}



export default Contact;